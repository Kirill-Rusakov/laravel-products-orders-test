<h1>Добро пожаловать!</h1>
<p><a href="{{ route('products.index') }}">Перейти к товарам</a></p>
<p><a href="{{ route('orders.index') }}">Перейти к заказам</a></p>