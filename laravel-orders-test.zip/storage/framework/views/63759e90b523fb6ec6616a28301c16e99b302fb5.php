<h1>Добро пожаловать!</h1>
<p><a href="<?php echo e(route('products.index')); ?>">Перейти к товарам</a></p>
<p><a href="<?php echo e(route('orders.index')); ?>">Перейти к заказам</a></p><?php /**PATH C:\Web, Gulp and other\web-development\Works\laravel-orders-test\resources\views/home.blade.php ENDPATH**/ ?>